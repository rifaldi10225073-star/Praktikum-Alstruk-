print("--- Kondisi Awal (Tugas 1, 2, & 3) ---")

nilai = 82
kehadiran = 90


syarat_nilai = nilai >= 75
syarat_kehadiran = kehadiran >= 80

print(f"Apakah nilai ({nilai}) >= 75? {syarat_nilai}")
print(f"Apakah kehadiran ({kehadiran}%) >= 80%? {syarat_kehadiran}")

lulus_and = syarat_nilai and syarat_kehadiran
print(f"Status Kelulusan (Menggunakan AND): {lulus_and}\n")

print("--- Perubahan Nilai Berdasarkan Tugas 4 ---")

nilai = 70

syarat_nilai = nilai >= 75
syarat_kehadiran = kehadiran >= 80
lulus_and = syarat_nilai and syarat_kehadiran

print(f"Apakah nilai baru ({nilai}) >= 75? {syarat_nilai}")
print(f"Apakah kehadiran ({kehadiran}%) >= 80%? {syarat_kehadiran}")
print(f"Status Kelulusan Baru (Menggunakan AND): {lulus_and}\n")

print("--- Percobaan dengan Operator 'or' (Tugas 5) ---")

lulus_or = syarat_nilai or syarat_kehadiran
print(f"Status Kelulusan Baru (Menggunakan OR): {lulus_or}")
