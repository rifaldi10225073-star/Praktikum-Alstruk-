print("=== Uji Coba Kombinasi 1 ===")

nama_1 = "Rian Wijaya"

nilai_tugas_1 = 80
nilai_ujian_1 = 85

rata_rata_1 = (nilai_tugas_1 + nilai_ujian_1) / 2

status_lulus_1 = rata_rata_1 >= 75

print(f"Nama Mahasiswa : {nama_1}")
print(f"Nilai Tugas    : {nilai_tugas_1}")
print(f"Nilai Ujian    : {nilai_ujian_1}")
print(f"Rata-rata Nilai: {rata_rata_1}")
print(f"Status Lulus   : {status_lulus_1}\n")

print("=== Uji Coba Kombinasi 2 ===")

nama_2 = "Siti Aminah"

nilai_tugas_2 = 70
nilai_ujian_2 = 72

rata_rata_2 = (nilai_tugas_2 + nilai_ujian_2) / 2

status_lulus_2 = rata_rata_2 >= 75

print(f"Nama Mahasiswa : {nama_2}")
print(f"Nilai Tugas    : {nilai_tugas_2}")
print(f"Nilai Ujian    : {nilai_ujian_2}")
print(f"Rata-rata Nilai: {rata_rata_2}")
print(f"Status Lulus   : {status_lulus_2}")
