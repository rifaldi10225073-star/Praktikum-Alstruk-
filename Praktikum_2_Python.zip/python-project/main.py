print(">>> Selamat Datang di Pemrograman Python <<<")
print("Praktikum 2 Operator Aritmatika")

harga = 12500
jumlah = 4

print("=== Variabel harga dan jumlah ===")
print("Harga :", harga)
print("Jumlah :", jumlah)

total_harga = harga * jumlah
sisa_pembagian = total_harga % 2000
harga_setelah_diskon = total_harga - 5000

print("Total Harga :", total_harga)
print("Sisa Pembagian :", sisa_pembagian)
print("Harga Setelah Diskon :", harga_setelah_diskon)

print("=== Tampilan Keseluruhan ===")
print("Harga per buku      : Rp", harga)
print("Jumlah buku         :", jumlah)
print("Total harga         : Rp", total_harga)
print("Sisa pembagian %2000: Rp", sisa_pembagian)
print("Harga setelah diskon: Rp", harga_setelah_diskon)

print(" ~~~ Ketentuan terakhir sudah selesai ~~~")
