nilai = [78, 85, 90, 85]
mahasiswa = {"nama": "Nadia", "kelas": "IF-A"}
koordinat = (5, 8)
angka = {2, 4, 4, 6, 8}

print("--- HASIL EKSEKUSI TUGAS ---")

print(f"1. Nilai pertama dari list: {nilai[0]}")

nilai.append(95)
print(f"2. List terbaru setelah ditambah 95: {nilai}")

print(f"3. Nama mahasiswa dari dictionary: {mahasiswa['nama']}")

print(f"4. Koordinat pertama dari tuple: {koordinat[0]}")

angka_unik_terurut = sorted(angka)
print(f"5. Angka unik terurut: {angka_unik_terurut}")
