print(">>> Selamat Datang di Pemrograman Python <<<")
print("Praktikum 1 Mengenali Tipe Data")

nama = "Fajar"
umur = 19
berat = 54.5
terdaftar = True

print("=== Nilai Variabel ===")
print("Nama :", nama)
print("Umur :", umur)
print("Berat :", berat)
print("Terdaftar :", terdaftar)

print("=== Tipe Data Variabel")
print("Tipe data 'nama'        :", type(nama))
print("Tipe data 'umur'        :", type(umur))
print("Tipe data 'berat'       :", type(berat))
print("Tipe data 'terdaftar'   :", type(terdaftar))

umur = 20
print("=== Setelah Umur Diubah ===")
print("Nilai umur baru :", umur)
print("Tipe data umur :", type(umur))

print("~~~ Ketentuan awal sampai akhir telah selesai ~~~")
